package utility;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

/**
 * This interface represents the input/output operations that the program carries
 * out on different file types.
 */
public interface WorkWithFileTypes {

  /**
   * This function is used to create a any portfolio.
   */
  void create(ArrayList<HashMap<String, String>> stockData);

  /**
   * This function is used to read data from a portfolio.
   */
  List<HashMap<String, String>> read();

  /**
   * This function is used to read the creation date of the file.
   */
  String getFileCreationDate();

  /**
   * This function is used to update data on a portfolio file.
   */
  boolean update(List<HashMap<String, String>> stocks);
}
